=== Woocommerce Auto Refresh Order ===
Contributors: gabriserra
Tags: auto refresh, refresh meta, meta tags, automatic refreshing, refresh a page, refresh pages, auto refresh post, auto refresh page, woocommerce auto refresh, order refresh
Requires at least: 4.7.5
Tested up to: 4.8
Stable tag: trunk
License: GPLv3 or later License
URI: http://www.gnu.org/licenses/gpl-3.0.html
WC requires at least: 3.0.7
WC tested up to: 3.0.7

Adds a setting tab on woo commerce settings in order to specify if you want an automatic refresh of the admin order page and after how many seconds.

== Description ==

Adds a setting tab on woo commerce settings in order to specify if you want an automatic refresh of the admin order page and after how many seconds.

== Installation ==

1. Upload the plugin to the '/wp-content/plugins/' directory
2. Activate the plugin through the 'Plugins' menu in WordPress

To use this plugin, go to woo commerce setting, simply enter the number of seconds you wish the page to refresh after in the box and enable it. 

== Frequently Asked Questions ==

N/A

== Screenshots ==

N/A

== Upgrade Notice ==

N/A

== Changelog ==

* 0.1 Initial version
 - Specify seconds to auto refresh the page/post
